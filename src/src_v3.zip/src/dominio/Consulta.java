package dominio;

import java.util.ArrayList;

import excepcion.BaseDatosException;
import basedatos.BaseDatos;

public class Consulta implements Comparable<Consulta> {
	
	private String nombreConsulta;
	private ArrayList<Campo> campos;
	private ArrayList<String[]> valores;
	
	public Consulta() {
		nombreConsulta = "";
		campos = new ArrayList<Campo>();
		valores = new ArrayList<String[]>();
	}

	public Consulta(Consulta consulta) {
		this.nombreConsulta = consulta.getNombreConsulta();
		this.campos = new ArrayList<Campo>();
		for (Campo campo: consulta.campos) {
			this.campos.add(campo);
		}
		this.valores = new ArrayList<String[]>();
		for (String[] valor: consulta.valores) {
			this.valores.add(valor);
		}
	}
	
	public String getNombreConsulta() {
		return nombreConsulta;
	}
	
	public void setNombreConsulta(String nombreConsulta) {
		this.nombreConsulta = nombreConsulta;
	}

	public void agregarCampo(Campo campo, String[] valor) {
		campos.add(campo);
		valores.add(valor);
	}
	
	public void quitarCampo(int posicion) {
		campos.remove(posicion);
		valores.remove(posicion);
	}
	
	public Campo obtenerCampo(int posicion) {
		if (posicion < 0 || posicion >= campos.size()) {
			return null;
		} else {
			return campos.get(posicion);
		}
	}

	public String[] obtenerValores(int posicion) {
		if (posicion < 0 || posicion >= valores.size()) {
			return null;
		} else {
			return valores.get(posicion);
		}
	}

	public void insertarConsulta(BaseDatos bd) throws BaseDatosException {
		String nombreCampo;
		String valor;
		for (int i = 0; i < campos.size(); i++) {
			nombreCampo = campos.get(i).getNombreCampo();
			valor = getCadenaValores(valores.get(i));
			bd.realizarAccion("INSERT INTO consulta VALUES("
					+ "'" + nombreConsulta + "' ,"
					+ "'" + nombreCampo + "' ," 
					+ "'" + valor + "')");
		}
	}
	
	public TramiteEspecifico[] ejecutarConsulta() {
		return null;
	}

	private String getCadenaValores(Object[] arreglo) {
		String cadena = "";
		if (arreglo == null || arreglo.length == 0) {
			return "";
		}
		for (int i = 0; i < arreglo.length; i++) {
			cadena += arreglo[i];
			if (i != (arreglo.length - 1)) {
				cadena += " / ";
			}
		}
		return cadena;
	}

	/** 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return nombreConsulta;
	}

	@Override
	public int compareTo(Consulta o) {
		return this.getNombreConsulta().compareToIgnoreCase(o.getNombreConsulta());
	}
}
