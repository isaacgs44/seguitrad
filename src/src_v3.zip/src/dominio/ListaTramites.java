package dominio;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import basedatos.BaseDatos;
import excepcion.BaseDatosException;
import excepcion.TramiteException;
import java.sql.ResultSet;

public class ListaTramites {

    private Tramite tramite;
    private ArrayList<TramiteEspecifico> listaTramites;
    private ArrayList<Consulta> listaConsultas;
    private boolean hayCambios;
    private BaseDatos bd;

    /**
     *
     */
    public ListaTramites() {
        inicializar();
    }

    private void inicializar() {
        tramite = null;
        listaTramites = new ArrayList<TramiteEspecifico>();
        listaConsultas = new ArrayList<Consulta>();
        hayCambios = false;
    }

    public Tramite getTramite() {
        return tramite;
    }

    /**
     * @param tramite
     */
    public void setTramite(Tramite tramite) {
        this.tramite = tramite;
    }

    /**
     * @return the listaTramites
     */
    public ArrayList<TramiteEspecifico> getListaTramitesEsp() {
        return listaTramites;
    }

    /**
     * @param listaTramites the listaTramites to set
     */
    public void setListaTramites(ArrayList<TramiteEspecifico> listaTramites) {
        this.listaTramites = listaTramites;
    }

    /**
     * @return the listaConsultas
     */
    public ArrayList<Consulta> getListaConsultas() {
        return listaConsultas;
    }

    /**
     * @param listaConsultas the listaConsultas to set
     */
    public void setListaConsultas(ArrayList<Consulta> listaConsultas) {
        this.listaConsultas = listaConsultas;
    }

    /**
     * @return the hayCambios
     */
    public boolean isHayCambios() {
        return hayCambios;
    }

    /**
     * @param hayCambios the hayCambios to set
     */
    public void setHayCambios(boolean hayCambios) {
        this.hayCambios = hayCambios;
    }

    /**
     * @return the bd
     */
    public BaseDatos getBd() {
        return bd;
    }

    /**
     * @param bd the bd to set
     */
    public void setBd(BaseDatos bd) {
        this.bd = bd;
    }

    public void agregarTramiteEspecifico(TramiteEspecifico tramite) {
        listaTramites.add(tramite);
    }

    public void agregarConsulta(Consulta consulta) throws TramiteException {
        // validar que no esté repetido el nombre
        for (Consulta c : listaConsultas) {
            if (c.getNombreConsulta().compareToIgnoreCase(consulta.getNombreConsulta()) == 0) {
                throw new TramiteException(TramiteException.CONSULTA_REPETIDA);
            }
        }
        listaConsultas.add(consulta);
        Collections.sort(listaConsultas);
    }

    /**
     * @throws BaseDatosException
     * @throws TramiteException
     */
    public void crearTramite() throws BaseDatosException, TramiteException {
        // crear bd y directorio
        bd = new BaseDatos(tramite.getNombreArchivo(), true);
        bd.crearTablas();
        // insertar los registros de la estructura del trámite
        tramite.crearTramite(bd);
    }

    public void quitarTramite() {
    }

    public void modificarTramite() throws BaseDatosException, TramiteException {
        // insertar los registros de la estructura del trámite
        tramite.actualizarTramite(bd);
    }

    /**
     * @throws BaseDatosException
     *
     */
    public void guardarArchivo() {
        // FALTA
//		for (Consulta consulta: getListaConsultas()) {
//			consulta.insertarConsulta(bd);
//		}
    }

    /**
     *
     */
    public void guardarArchivoComo() {
    }

    public void abrirArchivo() throws BaseDatosException, TramiteException, SQLException {
        FileDialog fd = new FileDialog(new Frame(), "Seleccionar trámite", FileDialog.LOAD);
        fd.setDirectory(System.getProperty("user.dir") + File.separator + "tramites");
        fd.setFile("*.trad");
        fd.setVisible(true);
        if (fd.getFile() != null) {
            // abrir bd
            bd = new BaseDatos(fd.getDirectory() + fd.getFile(), false);
            inicializar();
            // recuperar tramite
            tramite = new Tramite();
            tramite.recuperarTramite(bd, fd.getFile());

            //**********    TRABAJANDO ******/ falta recuperar trámites específicos y consultas

            ArrayList<Campo> campos = tramite.getCampos();
            ArrayList<Paso> pasos = tramite.getPasos();

            String consulta = "SELECT * FROM tramites_especificos";

            ResultSet rs = bd.realizarConsulta(consulta);
            int i = 0;
            this.listaTramites.clear();
            while (rs.next()) {
                TramiteEspecifico tramiteEspecifico = new TramiteEspecifico();
                ArrayList<String[]> valores = new ArrayList<>();

                tramiteEspecifico.setIdTramite(Integer.parseInt(rs.getString(1)));
                valores.add(0, new String[1]);
                valores.get(0)[0] = rs.getString(2);
                valores.add(1, new String[1]);
                valores.get(1)[0] = rs.getString(3);
                valores.add(2, new String[1]);
                valores.get(2)[0] = rs.getString(4);
                valores.add(3, new String[1]);
                valores.get(3)[0] = rs.getString(5);
                valores.add(4, new String[1]);
                valores.get(4)[0] = rs.getString(6);

                for (int j = 0; j < 5; j++) {
                    tramiteEspecifico.agregarCampo(campos.get(j), valores.get(j));
                }
                System.out.println("*****Numero de Campos***** " + campos.size());
                System.out.println("*****Numero de Valores***** " + valores.size());

                for (Paso p : pasos) {
                    PasoEspecifico pasoEspecifico = new PasoEspecifico();
                    pasoEspecifico.setNombrePaso(p.getNombrePaso());
                    // Falta. crear la repetición de pasos
                    pasoEspecifico.setRepeticion(p.getRepeticion());
                    pasoEspecifico.setRealizado(false);
                    pasoEspecifico.setFechaRealizacion(null);
                    pasoEspecifico.setDocumento("");
                    /*if (p.isObligatorio() && p.isConFechaLimite()) {
                    
                    fecha = fechas.get(index);
                    pasoEspecifico.setFechaLimite(fecha.getDate());
                    index++;
                    } else {
                    pasoEspecifico.setFechaLimite(null);
                    }*/

                    tramiteEspecifico.agregarPasoEspecifico(pasoEspecifico);
                }
                agregarTramiteEspecifico(tramiteEspecifico);

            }
            bd.cerrarConexion();
            if (bd.numRegistrosMeta_espec() != 5) {
                String consulta2 = "select   Valor, idRegistro,valor_defecto from meta_espec inner join "
                        + "tramites_especificos inner join tramites_especificos_campos where idCampo_numCampoMeta_espec=num_campo "
                        + "and idCampo_IdRegistro_tramiteEspec= idRegistro ";
                ResultSet rs1 = bd.realizarConsulta(consulta2);
                while (rs1.next()) {
                    ArrayList<String[]> valores = new ArrayList<>();
                    int k = 5;
                    for (TramiteEspecifico t : listaTramites) {
                        if (t.getIdTramite() == rs1.getInt(2)) {
                            valores.add(0, new String[1]);
                            valores.get(0)[0] = rs1.getString(1);
                            t.agregarCampo(campos.get(k), valores.get(0));
                            k++;
                        }
                    }

                }

            }

            System.out.println("elementos: " + listaTramites.size());
            for (TramiteEspecifico t : listaTramites) {
                System.out.println("ID: " + t.getIdTramite());

                for (int j = 0; j < t.getCampos().size(); j++) {
                    System.out.println("Campo: " + t.getCampos().get(j));
                    System.out.println("Valor: " + t.getValores().get(j)[0]);
                }
            }

        } else {
            // no se seleccionó nada o se canceló
            setBd(null);
        }
    }

    public void cerrarArchivo() {
        inicializar();
    }
}
